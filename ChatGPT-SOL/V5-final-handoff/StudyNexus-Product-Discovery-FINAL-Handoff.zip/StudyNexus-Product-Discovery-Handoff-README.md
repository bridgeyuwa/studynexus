# StudyNexus Product Discovery — FINAL Handoff Package

## Purpose

This package contains the authoritative current Product Discovery for StudyNexus and the minimum supporting registers needed to audit scope, concepts, resolutions and evidence traceability.

The historical 555-file corpus, reconstruction reports and earlier ledgers remain historical evidence. They are not required for ordinary product understanding and are intentionally not included in this handoff ZIP.

## Authoritative file

**`StudyNexus-Canonical-Product-Discovery-FINAL.md`** is the authoritative human-readable product baseline.

Downstream product terminology, domain analysis, architecture and implementation work must derive from this document. Historical artifacts must not silently override it. A later explicit product decision may supersede it.

## Supporting files

- **`StudyNexus-Canonical-Product-Concept-Register-FINAL.csv`** — machine-readable product concept inventory. It is not a DDD/class/database model.
- **`StudyNexus-Canonical-Capability-Scope-FINAL.csv`** — machine-readable capability and scope register. MVP membership, definition maturity, first-slice status and capability minimum are deliberately separate.
- **`StudyNexus-Product-Discovery-Resolution-Ledger-FINAL.csv`** — validated resolution record for the major issues settled or bounded during reconstruction/remediation.
- **`StudyNexus-Product-Discovery-Traceability-Map.csv`** — maps major canonical conclusions to claims, decisions, resolutions and source paths.

## Current MVP rule

> Everything still under current consideration remains in the current MVP unless actual evidence establishes rejection, explicit exclusion, current deferral, impossibility, irrelevance, supersession or another genuine reason that it is not part of the product.

Historical phase labels, underspecification, omission from the first vertical slice and an undefined capability minimum do not by themselves remove a capability from MVP.

The current package contains **26 ordinary current-MVP product capabilities**. Jurisdiction-aware internationalization semantics is a cross-cutting product principle/constraint and is not counted as an ordinary capability.

## Explicit assumptions

1. **Institution Offering / Discovery Programme:** Institution Offering is treated as the source-faithful institution-specific product concept; Discovery Programme is a separate StudyNexus-curated discovery concept; classification may be optional.
2. **Persistent identity / personalization / notifications:** these remain current MVP considerations while core anonymous discovery/search/comparison remains usable without an account.

These assumptions are visible and reversible; they are not disguised as proven facts.

## Genuine current deferrals

Only two major capabilities are positively deferred:

- Automated Deterministic Eligibility Evaluation.
- Examination Practice / Assessment.

Their related information capabilities remain in MVP.

## Genuine product-membership unknowns

Two areas remain unresolved as to whether they belong to the product at all:

- Rankings / Institutional Intelligence.
- Full Social / Community Product beyond information-quality contributions.

Neither is an MVP commitment or a permanent exclusion.

## Evidence-backed excluded capabilities

- Institution / Provider Self-Service.
- Public API / Developer Platform.
- External Transaction Execution.
- Multi-Country Public Rollout.

## Important negative knowledge

Do not infer that:

- the historical first vertical slice defines the strategic MVP;
- a historical Phase 2/3/Future/Later label is a current exclusion;
- underspecified means out of scope;
- user reports, scrapers or AI may silently create canonical truth;
- News owns durable canonical facts it reports;
- Search and Discovery are the same product behavior;
- Institution Offering and Discovery Programme are interchangeable;
- Organization is an accepted universal StudyNexus product concept;
- Rankings / Institutional Intelligence is an established capability;
- Nigeria-first delivery means Nigerian terminology should be hard-coded as universal;
- StudyNexus executes the external transactions it explains or links to.

## Handoff rule

This package is the stable Product Discovery baseline. It must be carried forward as a product artifact, not converted into architecture by reinterpretation of the old corpus.

If a future product decision changes StudyNexus, record that decision explicitly and update the canonical Product Discovery rather than allowing downstream modeling to redefine the product implicitly.

**Status: PRODUCTION-READY WITH EXPLICIT ASSUMPTIONS**
