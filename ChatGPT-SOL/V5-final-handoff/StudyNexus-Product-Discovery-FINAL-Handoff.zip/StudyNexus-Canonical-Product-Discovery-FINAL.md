# StudyNexus — Canonical Product Discovery — FINAL

**Status:** **PRODUCTION-READY WITH EXPLICIT ASSUMPTIONS**  
**Canonical baseline date:** 21 September 2026  
**Authority:** This document is the authoritative current Product Discovery for StudyNexus. The historical corpus and supporting ledgers remain evidence and traceability material; they are not required for ordinary understanding of the product.

---

## Executive Product Baseline

**StudyNexus is a Nigeria-first education information, discovery, knowledge and decision-support product that helps learners and their advisers find, understand, compare and judge the trustworthiness of educational opportunities, requirements, services and related information.**

Its product loop is:

```text
find / discover
→ understand
→ compare
→ verify trust and context
→ decide what to do next
→ hand off to the authoritative institution, provider or public body where action occurs
```

StudyNexus is primarily an **information and decision-support product**. It is not an enrolment processor, admissions decision-maker, examination operator, scholarship award manager, payment platform, visa-processing service, provider marketplace or general transaction platform.

The current product is governed by one scope rule:

> **Everything still under current consideration remains in the current MVP unless actual evidence establishes rejection, explicit exclusion, current deferral, impossibility, irrelevance, supersession or another genuine reason that it is not part of the product.**

Historical labels such as *Phase 2*, *Phase 3*, *Future*, *Later* or *Post-MVP* do not independently remove a capability from the current MVP. A capability may be in MVP and still be underspecified, outside the first vertical slice, or awaiting definition of its smallest useful form.

The canonical capability package currently contains:

- **26 ordinary current-MVP product capabilities**;
- **1 cross-cutting product principle/constraint** for jurisdiction-aware internationalization semantics;
- **4 evidence-backed excluded capabilities**;
- **2 genuinely current deferrals**;
- **2 genuine product-membership unknowns**.

This classification is a statement about product scope, not implementation order.

---

# Part I — Product Definition

## 1. Product purpose

StudyNexus exists to reduce the fragmentation, ambiguity, trust burden and comparison effort involved in education decision-making. Education information is spread across institutions, regulators, examination bodies, funding providers, announcements, service portals and editorial sources. The user often has to locate several sources, determine which one is authoritative, reconcile conflicting terminology, compare options that are described differently and decide which external actor must handle the next action.

StudyNexus addresses that problem by maintaining a structured and traceable representation of decision-relevant education information; helping users search and explore it; explaining context; supporting comparison and self-assessment; and making clear when authority or execution remains external.

## 2. Product category

StudyNexus combines five durable product roles:

- **Education knowledge:** structured, maintainable information rather than disconnected notices and pages.
- **Discovery:** exploration across institutions, offerings, pathways, geography, funding, services and related opportunities.
- **Search:** efficient retrieval when a user has a known or constrained target.
- **Decision support:** comparison, admissions understanding, self-assessment and contextual explanation.
- **Information quality:** provenance, review, freshness, conflict handling and controlled correction so users can judge whether information deserves trust.

Its value is not merely having more education data. Its value is reducing the work required to assemble a coherent, trustworthy picture from heterogeneous sources.

## 3. Geographic strategy

StudyNexus is **Nigeria-first in public delivery**. At the same time, the product must avoid treating Nigeria-specific concepts as universal when the underlying education concept is intended to generalize.

Jurisdiction-aware semantics are therefore a **cross-cutting product principle**, not a standalone user-facing capability. Geography, admission terminology, qualifications, regulatory status and education structures may vary by jurisdiction.

Current multi-country public rollout is outside the current product scope. The requirement is semantic correctness and future representational integrity, not present international launch.

## 4. What StudyNexus is not

StudyNexus does not currently:

- enrol or admit learners;
- make authoritative admission decisions;
- register users for examinations, take examination payments, publish official results or issue certification;
- select, award or disburse scholarships;
- execute transfers, internships, postgraduate applications or other provider workflows;
- process visas or government transactions;
- provide institution/provider self-service;
- expose a public developer/API platform;
- operate a full social network merely because it accepts reports or contributions;
- permit AI, scrapers or user submissions to silently become canonical truth;
- make every valid search/filter combination an indexable SEO page;
- launch public coverage across multiple countries.

Where useful, StudyNexus may explain, compare, guide and hand off to the competent external actor.

---

# Part II — Users, Problems and Outcomes

## 5. Current user model

The strongest supported user groups are:

### Secondary students and recent graduates

They are deciding what and where to study, understanding requirements, comparing institutions and offerings, interpreting admissions information, looking for funding and examinations information, and determining what action to take next.

### Current undergraduates

They have information needs beyond initial admission: progression through their current journey, transfer possibilities, internships, funding, career direction and postgraduate options.

### Parents and guardians

They support education choices and need understandable, trustworthy information about institutions, offerings, costs, requirements, opportunities and next steps.

### Guidance counsellors, teachers and advisers

They help learners interpret options and may need to compare multiple institutions, offerings and admission contexts efficiently.

Institutions, regulators, examination bodies, funding providers, publishers and education-service providers are important external actors and information authorities. They are not automatically current public end-user personas of StudyNexus.

## 6. Core problem space

### Fragmentation

Decision-relevant information is scattered across many independent sources. Users must assemble a connected picture manually.

**Product response:** structured education information connected across the user's decision journey.

### Trust

Information can be stale, conflicting, incomplete or copied from weak sources. Absence from a source can be mistaken for non-existence.

**Product response:** provenance, authority awareness, candidate-versus-canonical separation, controlled correction and explicit handling of uncertainty.

### Discoverability

Users often do not know the exact institution, offering title or terminology they should search for. Institutions may describe similar study opportunities differently.

**Product response:** known-target search plus broader discovery through curated concepts, classification, facets, geography and related options.

### Comparison

Institutions and providers describe relevant facts inconsistently, making alternatives difficult to compare.

**Product response:** comparable representations and comparison behavior without pretending heterogeneous concepts are naturally identical.

### Accessibility and comprehensibility

Information may exist but remain difficult to navigate, interpret or apply to a user's decision.

**Product response:** task-oriented journeys, explanatory information and contextual presentation rather than raw links alone.

## 7. Core user jobs

Users need to:

- find plausible institutions and study opportunities;
- understand what an institution actually offers;
- make sense of differing programme/course terminology;
- compare relevant alternatives;
- understand admission requirements, cut-offs, Post-UTME, catchment and ELDS;
- assess apparent fit against published requirements without mistaking that assessment for an official decision;
- find funding opportunities and understand criteria;
- understand examination information and important schedule changes;
- understand recent education developments;
- locate official education services and access points;
- use evergreen explanatory information for processes and decisions;
- understand career, transfer, postgraduate and internship pathways;
- understand their ongoing undergraduate journey;
- judge whether information is current, sourced and trustworthy;
- know when StudyNexus is explaining information and when an external authority must perform the next action.

## 8. Intended product outcomes

StudyNexus aims to produce:

- less fragmented research;
- less uncertainty about terminology and context;
- more coherent comparison of relevant alternatives;
- clearer admissions, funding, examination and service information;
- more visible provenance and trust context;
- less risk of treating stale or unreviewed information as authoritative;
- clearer transition from information to the correct next external action.

### Evidence limitation

The historical evidence strongly establishes these as StudyNexus's intended product problems and outcomes, but it contains limited completed primary-user research such as interviews, surveys, behavioral analytics or validated market experiments. They should therefore be understood as a coherent owner/stakeholder-defined product baseline with uneven empirical validation, not as proof that every problem has been independently validated at market scale.

---

# Part III — Product Principles

## 9. Preserve source reality

StudyNexus should preserve the terminology and factual context used by the institution or competent source. It must not rewrite an institution's actual offering merely to force it into a universal catalogue.

Normalization and curation may exist for discovery, but they remain distinguishable from source-faithful information.

## 10. Canonical information is not source evidence

A source, extracted information, a candidate change, accepted canonical StudyNexus information and a derived representation are different states with different authority.

StudyNexus may maintain its accepted canonical representation of an external fact, but that does not make StudyNexus the real-world authority that issued the fact.

## 11. MISSING ≠ DELETE

The disappearance of a fact from one source is evidence requiring interpretation. It does not, by itself, prove that the real-world fact ceased to exist.

## 12. Automated and public inputs do not silently decide truth

AI, scrapers and user reports may identify or suggest information. They do not silently mutate canonical StudyNexus information.

The applicable evidence, authority and review rules determine acceptance.

## 13. Search and Discovery are different product behaviors

**Search** is intentional retrieval of a known or constrained target.

**Discovery** is exploration of possibilities, related alternatives, combinations and pathways when the exact target is not already known.

StudyNexus needs both.

## 14. Discovery classification does not determine factual existence

An Institution Offering may exist and be useful even when it has not been mapped to a Discovery Programme or another curated classification.

## 15. Canonical information and public/indexable publication are different decisions

A canonical fact can exist without an indexable landing page. Publication and indexability must be selective product decisions rather than automatic consequences of a filter combination existing.

## 16. Jurisdiction matters

Education structures, geographic hierarchies, admission concepts, accreditation, approval, qualification recognition and related terminology can vary by country and authority.

Nigeria-first delivery must not turn local terminology into false global universals.

## 17. External action remains external unless explicitly adopted

StudyNexus may inform, explain, compare, route and hand off. It does not become the institution, regulator, examiner, scholarship provider, government service or other external provider merely because its product explains the task.

## 18. Anonymous core remains viable

Core search, discovery, comparison and information access must remain usable without requiring a public account. Persistent identity, personalization and notifications may add value without becoming prerequisites for the anonymous core.

## 19. Technology does not define the product

Implementation technologies, persistence patterns, search engines, packages, queues, repositories or folder structures do not establish product requirements merely because they appear in technical history.

---

# Part IV — Product Journeys

## 20. Institution discovery and evaluation

**User intent:** find institutions that plausibly match a learner's constraints and understand whether they merit further consideration.

StudyNexus brings together institution identity, geography, decision-relevant characteristics, offerings, external regulatory or trust information, related content and discovery criteria.

The product informs and compares. The institution remains responsible for its own operations, official communications and enrolment.

## 21. Institution Offering and programme discovery

**User intent:** understand what an institution actually offers and explore related or comparable study possibilities.

StudyNexus preserves an **Institution Offering** as source-faithful information about what a particular institution offers. It may separately use a **Discovery Programme** or another curated classification to support cross-institution discovery.

A factual offering is not invalid merely because it lacks discovery classification.

## 22. Admissions research

**User intent:** understand how admission works for the relevant institution or offering.

StudyNexus may present admission requirements, cut-offs, Post-UTME information, admission-cycle context, catchment/ELDS and other relevant policy information.

StudyNexus does not make the admission decision.

## 23. Requirements and self-assessment

**User intent:** determine whether declared circumstances appear consistent with published requirements before taking an external action.

StudyNexus may compare user-provided facts with published information and explain apparent fit or gaps. This is decision support, not an authoritative eligibility or admission determination.

Fully automated deterministic eligibility evaluation remains a separate deferred capability.

## 24. Comparison

**User intent:** compare plausible education choices using decision-relevant information.

Comparison may combine institution, offering, admissions, cost, regulatory, funding or other relevant information where the underlying concepts are sufficiently comparable.

A dedicated “Compare page” is a presentation choice, not the definition of the capability.

## 25. Funding and scholarship discovery

**User intent:** find relevant funding and understand what it provides, who can apply and what restrictions or dates matter.

StudyNexus's role is information, discovery, explanation, matching where appropriate and external handoff. Selection, award and disbursement remain with the provider.

## 26. Catchment and ELDS understanding

**User intent:** understand whether geographic admission-policy considerations affect the relevant admission context.

Catchment and ELDS are contextual policy concepts. They are not generic permanent labels that can safely be attached to an institution without context.

## 27. Examination information

**User intent:** understand an examination and relevant time-specific administration or schedule information.

The capability may include information about examination authorities, examination products, administrations/sittings and schedule changes such as postponements or cancellations. Its exact minimum boundary still requires refinement.

StudyNexus does not operate the examination. Examination practice, attempts, scoring and learner progress are separately deferred.

## 28. News and current education information

**User intent:** understand a recent education development, announcement or change.

News is time-sensitive editorial information. A News item may report a change to an institution, offering, admission rule or other durable fact, but the News item does not become the canonical owner of that durable fact.

## 29. Evergreen information, guides and resources

**User intent:** understand stable or slowly changing education topics, processes, pathways and decisions.

This capability is inside the MVP but its minimum editorial/product definition remains underspecified. Historical content hierarchies are evidence of content needs, not binding product structure.

## 30. Education Services & Access

**User intent:** identify an education-related service or task, understand requirements and find the authoritative point of access.

StudyNexus provides information, guidance, discovery and handoff. It does not execute the external service unless a future explicit product decision changes that boundary.

## 31. Undergraduate current journey

**User intent:** receive useful information for decisions that occur after initial admission while the learner is currently studying.

This includes the wider current-student information journey represented historically by WF7. The workflow label is not a requirement that the final product expose one particular screen or information architecture.

## 32. Career pathways

**User intent:** understand plausible career directions and implications associated with education choices.

Career pathways remain in the current MVP but are underspecified. StudyNexus must not present education choices as guaranteeing employment outcomes.

## 33. Transfer information

**User intent:** understand options, requirements and constraints when considering movement between institutions, programmes or education paths.

StudyNexus explains the pathway; it does not execute the transfer.

## 34. Postgraduate pathways

**User intent:** discover and understand postgraduate study opportunities, entry pathways and relevant next steps.

The capability remains MVP but its first useful minimum is not yet fully specified.

## 35. Internship information and discovery

**User intent:** find and understand internship or practical-experience opportunities relevant to the learner's education and career journey.

The current product evidence supports information/discovery, not application or placement execution.

## 36. User contribution and correction

**User intent:** report information that appears missing, stale, wrong or incomplete.

A contribution becomes evidence or candidate input to StudyNexus's information-quality process. It does not become canonical truth merely because a user submitted it.

This capability does not imply a full social/community product.

## 37. Persistent identity, personalization and notifications

Persistent identity, personalization and notifications remain current MVP considerations, while the anonymous core remains independently usable.

- **Persistent identity** may support saved state and continuing journeys; its boundary remains under refinement.
- **Personalization** may adapt information and guidance to user context; its minimum remains underspecified.
- **Notifications** may alert users to relevant changing information or opportunities; triggers, trust rules and consent remain underspecified.

None of these capabilities is required to make core anonymous discovery/search/comparison viable.

---

# Part V — Product Information Model

This section describes the product's information concepts. It is not a database, DDD or class model.

| Product concept | Canonical product-level meaning |
|---|---|
| **Institution** | A recognized educational institution represented in StudyNexus. Institution identity is distinct from arbitrary related organizations and from a campus/location. |
| **Campus** | A named institutional location/branch context where real offering, admission, service or accreditation facts may vary. |
| **Institution Offering** | The source-faithful fact that a specific institution offers a named course/programme, preserving the institution’s own terminology and real-world offering context. |
| **Discovery Programme** | A StudyNexus-curated concept used to group or relate institution offerings for cross-institution discovery, comparison, facets and publication where useful. |
| **Admission** | Information about how a learner may enter an institution or offering, including published requirements, cutoffs, cycles and jurisdiction-specific policy factors. |
| **Admission Requirement** | A published condition for admission. It is not itself a candidate-specific eligibility result. |
| **Eligibility** | The outcome/assessment of facts against rules in a particular context. Admission eligibility and funding eligibility are not assumed to be one universal rule system. |
| **Catchment** | A geographic admission-policy consideration defined by an authoritative admission policy; it is not physical proximity and not a permanent institution attribute. |
| **ELDS** | Educationally Less Developed States: a Nigeria-specific admission classification used where authoritative policy applies. |
| **Funding Opportunity** | An educational funding opportunity such as scholarship, grant, bursary or aid, with benefits, criteria, dates, restrictions, provider and authoritative handoff. |
| **Accreditation** | A time-bounded decision or status granted by a competent authority about the quality/compliance of an institution, offering, programme, campus or other scoped educational object, according to the authority's jurisdiction and scheme. |
| **Qualification Recognition** | An external authority's judgment about whether a qualification, award or credential is recognized or accepted for a stated purpose or jurisdiction. |
| **Institution Approval / Recognized Status** | An externally granted status indicating whether an institution is approved, licensed, recognized, listed or otherwise valid under a competent authority's rules. |
| **Examination Product** | A named examination or assessment offering such as a public or standardized examination, distinct from a particular administration/sitting and from practice activity. |
| **Examination Administration** | A particular administration, sitting, session or cycle of an examination product in a defined time/context. |
| **Examination Schedule Event** | A time-sensitive event affecting an examination administration, such as a scheduled sitting, postponement, cancellation or other published change. |
| **News** | Time-sensitive editorial information that explains educational developments, announcements or changes without becoming the canonical owner of durable institution/offering/admission facts. |
| **Evergreen Guide / Resource** | Longer-lived educational information that explains stable or slowly changing topics, processes, decisions and pathways outside time-sensitive News. |
| **Education Service** | An education-related service or task a user may need to understand, locate or access, where StudyNexus primarily provides information, guidance and authoritative handoff rather than executing the external service. |
| **Source** | An identifiable origin from which StudyNexus receives information or evidence, with provenance and authority characteristics that may differ by fact type and context. |
| **Candidate Information / Candidate Change** | Sourced or extracted information that may imply a new fact or change but has not yet been accepted into StudyNexus canonical information. |
| **Canonical StudyNexus Information** | The current StudyNexus representation accepted for product use after applying the relevant evidence, normalization and review rules; it remains a representation of external reality, not ownership of the external authority's underlying fact. |
| **Derived Representation** | A representation calculated, normalized, classified or projected from canonical and/or curated StudyNexus information for discovery, search, comparison, publication or presentation. |
| **Provenance** | Traceable information about where a StudyNexus fact, candidate, interpretation or publication came from and how it reached its current state. |
| **User Contribution / Report** | Information submitted by a user to flag, add, challenge or contextualize StudyNexus information; it is an input to information quality, not canonical truth by submission alone. |
| **Search** | Intentional retrieval of known or constrained education information using text, filters or other explicit criteria. |
| **Discovery** | Exploration of education possibilities, alternatives, combinations and related information when the user does not already know the exact target. |
| **Classification** | A StudyNexus-curated association that places source-faithful offerings or other information into discovery groupings, taxonomies or views without rewriting the underlying source-faithful fact. |
| **Publication / Indexability** | The product decision about whether information or a discovery surface should be publicly exposed and/or made canonical/indexable for search engines; this is distinct from whether the underlying canonical fact exists. |
| **Comparison** | A decision-support behavior that places relevant education options or facts side by side using comparable information. |
| **Career Pathway** | Information connecting study choices to plausible career directions, occupations or next-step outcomes, without asserting deterministic employment results. |
| **Undergraduate Current Journey / WF7** | The information journey for a current undergraduate seeking to understand their present educational path, progression and relevant next decisions. |
| **Transfer** | Information supporting a learner who is considering moving between institutions, programmes or education paths, including relevant requirements and constraints where known. |
| **Postgraduate Pathway / Opportunity** | Information that helps users discover and understand postgraduate study options and relevant entry/pathway information. |
| **Internship Opportunity** | Information about internship or practical-work opportunities relevant to learners' education/career journey. |
| **Public Account / Persistent Identity** | A persistent user identity that can support saved state or personal capabilities. It is not required for anonymous core discovery/search/comparison, but under the current MVP-default rule remains in MVP consideration. |
| **Personalization** | Adaptation of information, recommendations, saved state or guidance to a user's declared or persistent context without making personalization a prerequisite for core anonymous discovery. |
| **Notification** | A product-initiated alert or update to a user about relevant educational information or changes, where the user has an appropriate delivery context/consent. |
| **Country / Administrative Area** | Geographic context used to locate institutions/services and interpret discovery, admission, funding and other jurisdiction-dependent information. |


## 38. Important distinctions

The following distinctions are part of the current Product Discovery and must not be collapsed casually:

- **Institution Offering ≠ Discovery Programme.**
- **Discovery Programme ≠ ProgrammeInstance.**
- **Accreditation ≠ Qualification Recognition.**
- **Institution Approval / Recognized Status ≠ Accreditation.**
- **Admission Requirement ≠ Eligibility.**
- **Self-Assessment ≠ authoritative admission decision.**
- **Search ≠ Discovery.**
- **News ≠ durable canonical fact.**
- **Source ≠ Canonical StudyNexus Information.**
- **User Contribution ≠ canonical truth.**
- **Organization** is not an accepted universal StudyNexus product concept; it remains an unresolved possible abstraction.
- **Rankings / Institutional Intelligence** is not an established product capability.

---

# Part VI — Product Capabilities

The capability model describes durable things StudyNexus must be able to do. It does not prescribe pages, modules or implementation components.

### Trusted information, institutions and discovery
| Capability | Product responsibility | MVP status | Definition maturity |
|---|---|---|---|
| **Trusted Education Information Management** | Acquire, reconcile, maintain, explain and present trustworthy education information with provenance and controlled correction. | MVP — defined | well defined |
| **Institution Discovery** | Help users find and explore educational institutions using meaningful criteria and geography. | MVP — defined | well defined |
| **Institution Information** | Present structured, trustworthy institution identity, location, status and other decision-relevant information. | MVP — defined | well defined |
| **Institution Offering Information** | Represent and expose what an institution actually offers using source-faithful terminology and relevant real-world context. | MVP — explicit assumption required | dependent on explicit assumption |
| **Programme / Discovery Curation** | Create and maintain StudyNexus-curated discovery concepts/classifications that help users find comparable or related institution offerings without rewriting source-faithful terminology. | MVP — explicit assumption required | dependent on explicit assumption |
| **Comparison** | Support side-by-side or contextual comparison of relevant education choices using comparable facts. | MVP — defined | partially defined |
| **Search** | Enable intentional retrieval of known or constrained education information using text and structured criteria. | MVP — defined | well defined |
| **Discovery / Exploration** | Enable users to explore alternatives, combinations, related opportunities and geographic options when they do not know the exact target. | MVP — defined | well defined |

### Admissions, funding and regulatory context
| Capability | Product responsibility | MVP status | Definition maturity |
|---|---|---|---|
| **Admissions Information** | Explain institution/offering admission information such as requirements, cut-offs, Post-UTME and applicable admission context. | MVP — defined | well defined |
| **Requirements and Self-Assessment** | Let users understand published requirements and compare their declared circumstances against them without claiming a final admissions decision. | MVP — defined | partially defined |
| **Funding / Scholarship Discovery** | Inform users about scholarships, grants, bursaries, aid and other funding opportunities, explain criteria and hand off to providers where action is external. | MVP — defined | partially defined |
| **Catchment / ELDS Information** | Explain admission catchment and Educationally Less Developed States (ELDS) rules in the context where they actually apply. | MVP — defined | well defined |
| **Accreditation / Approval / Qualification-Recognition Information** | Represent and explain externally granted regulatory/recognition statuses using the correct contextual meaning rather than a universal Recognition label. | MVP — boundary requires refinement | underspecified |

### Current and explanatory education information
| Capability | Product responsibility | MVP status | Definition maturity |
|---|---|---|---|
| **News / Time-Sensitive Education Information** | Publish time-sensitive education reporting/updates while keeping durable canonical facts in their proper information layer. | MVP — defined | well defined |
| **Education Services & Access** | Help users discover, understand and reach education-related services/tasks and authoritative access points. | MVP — defined | partially defined |
| **Examination Information / Schedules** | Provide trustworthy examination information and, where defined, time-specific administration/schedule changes without operating the examination. | MVP — boundary requires refinement | underspecified |
| **Evergreen Guides / Resources** | Provide longer-lived explanatory education content and structured resources that support decisions and understanding. | MVP — underspecified | underspecified |

### Ongoing learner pathways
| Capability | Product responsibility | MVP status | Definition maturity |
|---|---|---|---|
| **Career Pathways** | Connect education choices to plausible career directions and next-step information without promising employment outcomes. | MVP — underspecified | underspecified |
| **Undergraduate Current Journey / WF7** | Support current undergraduates with information relevant to their ongoing educational journey and next decisions. | MVP — defined | partially defined |
| **Transfer Information** | Help users understand transfer options, requirements and relevant institution/programme constraints. | MVP — underspecified | underspecified |
| **Postgraduate Pathways** | Help users discover and understand postgraduate study opportunities and entry pathways. | MVP — underspecified | underspecified |
| **Internship Information / Discovery** | Help users discover and understand internship/practical-experience opportunities relevant to education/career journeys. | MVP — underspecified | underspecified |

### Contribution and persistent user capabilities
| Capability | Product responsibility | MVP status | Definition maturity |
|---|---|---|---|
| **Community/User-Contributed Information Input** | Accept user reports or contributions as evidence/candidate input to information-quality processes. | MVP — defined | partially defined |
| **Public Accounts / Persistent Identity** | Provide persistent user identity only where it supports valuable persistent/personal capabilities while preserving anonymous core discovery/search/comparison. | MVP — boundary requires refinement | underspecified |
| **Personalization** | Adapt information/guidance to user context or persistent preferences without making personalization mandatory for core use. | MVP — underspecified | underspecified |
| **Notifications** | Alert users to relevant changing information/opportunities when an appropriate delivery/consent context exists. | MVP — underspecified | underspecified |



## 39. Cross-cutting principle: Internationalization semantics

Jurisdiction-aware semantics applies across relevant product capabilities. It is a **product principle / cross-cutting constraint**, not an ordinary standalone product capability.

It requires StudyNexus to avoid hard-coding local Nigerian terminology into concepts that are intended to represent information across jurisdictions, while preserving Nigeria-first public delivery.

## 40. Capability classification summary

The current capability register contains:

| Classification | Count | Meaning |
|---|---:|---|
| Ordinary current-MVP product capabilities | **26** | In strategic MVP, regardless of definition maturity or first-slice sequencing |
| Cross-cutting product principles/constraints | **1** | Internationalization semantics; not counted as an ordinary capability |
| Evidence-backed excluded capabilities | **4** | Outside the current product boundary |
| Genuinely current deferrals | **2** | Positively deferred by current evidence |
| Genuine product-membership unknowns | **2** | Product membership itself is not established |

---

# Part VII — Trust, Provenance and Information Quality

## 41. Product-level information flow

The product's trust model is conceptually:

```text
external source / user report / observed material
        ↓
evidence or extracted information
        ↓
candidate information / proposed change
        ↓
matching, comparison and conflict recognition
        ↓
review under applicable authority and quality rules
        ↓
accepted Canonical StudyNexus Information
        ↓
derived discovery / comparison / search / publication representations
```

This is a product responsibility model, not an implementation pipeline specification.

## 42. Canonical trust rules

1. Source evidence is not canonical truth.
2. Candidate information is not canonical truth.
3. Derived representations do not acquire authority over their inputs.
4. User reports are evidence/input, not direct canonical mutations.
5. AI extraction or recommendation may assist but cannot silently establish canonical state.
6. **MISSING ≠ DELETE.**
7. Conflicting sources require interpretation rather than a simple newest-source-wins rule.
8. Historical observations may remain valuable even after the current canonical representation changes.
9. Freshness matters, but one global freshness threshold is not established for all information categories.
10. Trust signals presented to users must not imply more certainty than the evidence warrants.

## 43. Why provenance is a product requirement

Provenance allows StudyNexus to answer:

- Where did this information come from?
- Which authority or source supports it?
- When was it observed or verified?
- Was conflicting evidence present?
- Was the information accepted, rejected or superseded?
- Why does the current StudyNexus representation exist?

This is central to the product's trust proposition, not merely a technical audit-log requirement.

---

# Part VIII — Information Ownership and External Boundaries

StudyNexus often **represents** authoritative external facts. Representation does not transfer real-world authority to StudyNexus.

| Information category | Real-world authority | StudyNexus responsibility | StudyNexus-derived layer | External boundary |
|---|---|---|---|---|
| Institution facts | Institution, regulator or other competent source depending on the fact | Maintain accepted institution representation with provenance | Search, discovery and comparison views | Institution/regulator remains external authority |
| Institution Offering | Institution and applicable authorities | Preserve source-faithful offering representation | Discovery Programme/classification, comparison and search | Institution handles actual study/enrolment |
| Admissions, cut-offs and requirements | Institution, JAMB and other competent admission authorities | Maintain and explain accepted admission information | Self-assessment and contextual guidance | Admission decision/application remains external |
| Catchment / ELDS | Competent admission-policy authority | Represent contextual policy | Discovery and explanation | Final admission outcome remains external |
| Accreditation / institution approval | Competent regulator/accreditation authority | Represent authority decision/status accurately | Trust and comparison display | Authority owns the regulatory decision |
| Qualification recognition | Competent recognition/credential authority | Represent recognition information | Guidance and comparison | Recognition outcome remains external |
| Funding opportunities | Funding provider/awarding body | Represent opportunity, benefit, criteria, restrictions and dates | Funding discovery/matching | Application, selection, award and disbursement remain external |
| Examination information | Examination authority | Represent examination and schedule/change information | Discovery, explanation and possible alerts | Registration, payment, official result/certification remain external |
| News | StudyNexus editorially owns its report; underlying facts may have external authorities | Publish and maintain the news item | Search/discovery presentation | Durable external fact belongs in its canonical category |
| Education services | External provider or public authority | Explain service/access information | Service discovery/guidance | Service execution remains external |
| Career/transfer/postgraduate/internship information | Varies by provider, institution or source | Maintain accepted explanatory/discovery information | Guidance and related discovery | Applications, placements and official decisions remain external |
| User contribution | Contributor owns the submission, not authoritative truth | Evaluate as evidence/candidate input | Trust/review status | No authority is implied by submission |
| Derived search/discovery representation | StudyNexus | Derive/rebuild from accepted and curated information | It is the product-facing representation | Does not supersede canonical source representations |

For any information category, five questions should remain distinct:

1. Who owns the real-world authoritative fact?
2. What does StudyNexus accept as its current canonical representation?
3. What does StudyNexus derive or curate from it?
4. What may users contribute as evidence?
5. Which next action remains external?

---

# Part IX — Search, Discovery, Comparison and Publication

## 44. Search

Search supports a user who has a known or constrained target. It may use text, structured criteria and filters.

The product meaning of Search is independent of any particular search technology.

## 45. Discovery

Discovery supports exploration when the user does not already know the exact target. It can span institutions, offerings, study concepts, geography, funding, services and related pathways.

Discovery may use StudyNexus-curated classifications or relationships. Those derived concepts must not erase source-faithful information.

## 46. Comparison

Comparison is decision support that brings relevant alternatives or facts into a comparable view. It depends on understanding where concepts are genuinely comparable and where contextual differences must be preserved.

Comparison is a capability, not necessarily one dedicated page.

## 47. Publication and indexability

Public availability, canonical publication and search-engine indexability are not synonymous with data existence.

StudyNexus may provide dynamic search/filter experiences without turning every valid combination into a permanent indexable page.

The product principle is:

> **Indexability is a selective publication decision based on the usefulness and integrity of the surface, not an automatic consequence of a query combination existing.**

SEO supports product discoverability but does not define the underlying product information.

---

# Part X — Current MVP

## 48. Governing MVP rule

> **Everything currently under consideration remains in the current MVP unless actual evidence establishes rejection, explicit exclusion, current deferral, impossibility, irrelevance, supersession or another genuine reason that it is not part of the product.**

This rule is an adopted current product-owner scope rule.

It follows that:

- historical delivery phases do not define current MVP membership;
- underspecification does not remove a capability from MVP;
- absence from the first vertical slice does not remove a capability from MVP;
- an undefined capability minimum does not remove a capability from MVP.

## 49. Four dimensions that must remain separate

### MVP scope

Whether the capability belongs to the current product.

### Definition maturity

How precisely its intended product behavior has been defined.

### Implementation sequencing

Whether it appears in the first vertical slice or another delivery sequence.

### Capability minimum

Whether the smallest useful form of the capability is sufficiently defined.

These dimensions must not be used as substitutes for one another.

## 50. Current strategic MVP envelope

The 26 ordinary current-MVP capabilities are:

1. Trusted Education Information Management
2. Institution Discovery
3. Institution Information
4. Institution Offering Information
5. Programme / Discovery Curation
6. Admissions Information
7. Requirements and Self-Assessment
8. Comparison
9. Search
10. Discovery / Exploration
11. Funding / Scholarship Discovery
12. Catchment / ELDS Information
13. News / Time-Sensitive Education Information
14. Education Services & Access
15. Examination Information / Schedules
16. Evergreen Guides / Resources
17. Career Pathways
18. Undergraduate Current Journey / WF7
19. Transfer Information
20. Postgraduate Pathways
21. Internship Information / Discovery
22. Community/User-Contributed Information Input
23. Public Accounts / Persistent Identity
24. Personalization
25. Notifications
26. Accreditation / Approval / Qualification-Recognition Information

**Internationalization Semantics** applies across the product as a principle/constraint and is not counted as a 27th ordinary capability.

## 51. Current-MVP capabilities with incomplete definition

The following remain inside MVP while requiring additional product definition:

- Institution Offering and Programme/Discovery Curation — explicit assumption-dependent.
- Examination Information / Schedules — boundary requires refinement.
- Evergreen Guides / Resources — underspecified.
- Career Pathways — underspecified.
- Transfer Information — underspecified.
- Postgraduate Pathways — underspecified.
- Internship Information / Discovery — underspecified.
- Public Accounts / Persistent Identity — boundary requires refinement.
- Personalization — underspecified.
- Notifications — underspecified.
- Accreditation / Approval / Qualification-Recognition Information — boundary requires refinement.

This incompleteness is visible by design. It does not shrink MVP.

---

# Part XI — Boundaries and Exclusions

Four capabilities are explicitly outside the current product boundary.

## 52. Institution / Provider Self-Service

StudyNexus does not currently provide a self-service product through which institutions or providers manage their public presence or operational workflows.

## 53. Public API / Developer Platform

A public developer-facing data or capability platform is not part of the current product.

## 54. External Transaction Execution

StudyNexus does not execute enrolment applications, official admission processing, examination registration/payment/results/certification, scholarship selection/disbursement, visas, provider transactions or equivalent external workflows.

Information, guidance and handoff may exist without transaction ownership.

## 55. Multi-Country Public Rollout

Current public delivery is Nigeria-first. Jurisdiction-aware semantics are required now, but multi-country public launch is not.

## 56. Additional product boundaries

The following are product rules rather than separate excluded capability rows:

- AI, scrapers and user reports cannot silently establish canonical truth.
- StudyNexus does not indiscriminately create indexable SEO pages from every filter combination.
- User contribution/report input does not establish a full social/community product.
- News does not become the owner of durable canonical facts it reports.

---

# Part XII — Genuine Current Deferrals

Only two validated capabilities are positively deferred.

## 57. Automated Deterministic Eligibility Evaluation

StudyNexus retains published requirements and self-assessment in the current MVP. Deterministic evaluation of a candidate profile against structured rules remains deferred until the product has sufficiently reliable rules, data and definition.

This deferral does not remove admissions information or self-assessment from MVP.

## 58. Examination Practice / Assessment

Practice questions, attempts, scoring, learner progress and related assessment-engine behavior remain deferred.

This deferral does not remove examination information or schedule/change information from MVP.

---

# Part XIII — Genuine Product-Membership Unknowns

## 59. Rankings / Institutional Intelligence

The evidence does not currently establish whether Rankings / Institutional Intelligence is a StudyNexus product capability.

Possible forms such as imported rankings, normalized metrics or StudyNexus-generated intelligence remain hypotheses. This is neither an MVP commitment nor a permanent exclusion.

## 60. Full Social / Community Product

StudyNexus currently includes user contribution/report input for information quality.

That does not establish a broader social/community product with profiles, feeds, discussion or other community interaction. Whether such a product belongs in StudyNexus remains genuinely unresolved.

---

# Part XIV — Explicit Assumptions

Two assumptions remain necessary to make the current Product Discovery coherent.

## 61. Institution Offering / Discovery Programme distinction

**Assumption:** An **Institution Offering** is the preferred product/business term for a source-faithful institution-specific study offering. A **Discovery Programme** is a separate StudyNexus-curated discovery concept. Classification may be optional, and a valid Institution Offering may exist without a Discovery Programme mapping.

**Why this assumption exists:** historical product/model evolution established a real need to preserve institution-specific terminology and contextual variation, while later discovery established a separate need for StudyNexus-curated cross-institution discovery.

**What remains uncertain:** the exact product vocabulary for offering variants/context such as campus, delivery mode, study mode or cycle; and the precise classification cardinalities.

**Product impact:** both Institution Offering information and Programme/Discovery Curation remain current-MVP capabilities.

## 62. Persistent identity, personalization and notifications

**Assumption:** The historical principle that no account is required for core anonymous discovery constrains the anonymous capability minimum; it is not evidence that persistent identity, personalization or notifications are currently outside strategic MVP.

**What remains uncertain:** the persistent jobs that justify identity, privacy/consent rules, the smallest useful saved-state/personalization behavior, and trusted notification triggers/channels.

**Product impact:** persistent identity, personalization and notifications remain MVP considerations while the anonymous core remains usable without an account.

---

# Part XV — Open Questions and Evidence Gaps

Open questions describe incomplete product definition. They do not automatically remove associated capabilities from MVP.

| Area | Open question | Affects | Evidence needed |
|---|---|---|---|
| **Institution Offering context** | What vocabulary best represents meaningful offering variation such as campus, delivery mode, study mode or cycle without over-generalizing? | Definition/modeling vocabulary | Representative source examples across institutions and later vocabulary work. |
| **Discovery Programme** | Which classification schemes are genuinely useful, and what mapping cardinalities are required? | Definition and curation rules | Real offering-classification examples and product usage evidence. |
| **Career pathways** | What minimum user decision should the capability support, and which career facts are trustworthy enough to present? | Capability minimum and evidence model | Direct user research and source research. |
| **Transfers** | Which transfer questions and requirements should the first useful capability explain? | Capability minimum | Institution/jurisdiction examples and user research. |
| **Postgraduate pathways** | What is the first useful postgraduate discovery/information minimum? | Capability minimum | User and source research. |
| **Internships** | Is the product role primarily discovery, curation or guidance, and what source model is credible? | Capability boundary and minimum | User/provider/source research. |
| **Examinations** | Which parts of examination, administration and schedule/change information belong in the minimum information capability? | Capability boundary | Examples across examination systems and source authorities. |
| **Evergreen content** | Which content types and lifecycle are minimum, and which historical content structures remain useful? | Content minimum and editorial behavior | Product/editorial definition. |
| **Persistent identity** | Which persistent jobs justify identity while preserving anonymous core use? | Capability boundary and privacy | User research and product/privacy design. |
| **Personalization** | Which outcomes and inputs justify personalization? | Capability minimum | User research and experiments. |
| **Notifications** | Which trusted changes justify alerts, and what consent/delivery conditions are required? | Capability minimum and trust rules | User research and trust policy. |
| **Source authority** | How should source precedence vary by information category when sources conflict? | Trust/business rules | Category-specific authority analysis. |
| **Trust signals** | Which provenance, freshness and confidence cues help users make better decisions without overstating certainty? | UX and trust policy | Usability/user research. |
| **Accreditation / approval / recognition** | What minimum Nigeria-first vocabulary is required for scope, authority, effective period and status? | Product vocabulary and source interpretation | Regulator-source analysis. |
| **SEO publication** | What exact product criteria make a dynamic discovery combination worthy of canonical/indexable publication? | Publication policy | Search/SEO evidence and content-quality policy. |
| **Rankings / Institutional Intelligence** | Does a real user problem justify this capability, and if so is the role imported ranking, normalized observation or StudyNexus-derived intelligence? | Product-membership research | Direct discovery and user research. |
| **Full social/community product** | Is there a distinct social/community opportunity beyond information-quality contributions? | Product-membership research | User research and opportunity definition. |


## 63. Material evidence limitation

The most important cross-cutting evidence limitation remains the relative scarcity of direct primary-user research.

That limitation does **not** invalidate the owner-defined current product baseline. It does mean that:

- relative problem priority may change with stronger user evidence;
- some underspecified capability minimums may be narrowed, expanded or reframed;
- personalization, notifications and several current-student journeys have lower empirical confidence than the core institution/admissions/discovery problem;
- rankings and a full community product should not be promoted without substantive discovery.

---

# Part XVI — Product Baseline

## 64. What StudyNexus currently is

StudyNexus is a **Nigeria-first trusted education information, discovery, knowledge and decision-support product**.

It brings together education information from heterogeneous authorities and providers, maintains a controlled and provenance-aware StudyNexus representation, helps users search and discover institutions, offerings and related opportunities, explains admissions and other contextual requirements, supports comparison and self-assessment, and provides guidance across funding, examinations, services, current-student and future-pathway decisions.

Its product responsibility ends where the competent external actor must execute the real-world transaction or authoritative decision.

## 65. What the current MVP is

The current MVP is the 26-capability strategic product envelope described in this document, governed by the rule that current consideration remains in MVP unless positive evidence removes or defers it.

The MVP includes both mature capabilities and intentionally underspecified capabilities. It is broader than the first vertical slice and should not be reduced to that implementation sequence.

Jurisdiction-aware internationalization semantics applies as a cross-cutting product principle rather than an ordinary capability.

## 66. What StudyNexus explicitly does not do

The current product excludes:

- institution/provider self-service;
- a public API/developer platform;
- execution of external education transactions;
- current multi-country public rollout.

It also rejects silent canonical mutation by AI/scrapers/user reports and indiscriminate indexation of arbitrary filter combinations.

## 67. What remains uncertain without invalidating the baseline

The Product Discovery remains authoritative despite bounded uncertainty around:

- exact contextual vocabulary for Institution Offerings and their curated discovery mappings;
- capability minimums for examinations, evergreen resources, careers, transfers, postgraduate pathways, internships, persistent identity, personalization and notifications;
- detailed accreditation/approval/qualification-recognition semantics;
- category-specific source precedence and public trust-signal design;
- whether Rankings / Institutional Intelligence belongs to the product;
- whether a full social/community product belongs to StudyNexus.

Those uncertainties are explicit rather than hidden.

---

## Final Status

# **PRODUCTION-READY WITH EXPLICIT ASSUMPTIONS**

This document is the authoritative current Product Discovery for StudyNexus.

The two explicit assumptions are:

1. **Institution Offering and Discovery Programme are distinct, with optional discovery classification.**
2. **Persistent identity, personalization and notifications remain current MVP considerations while the anonymous core remains usable without an account.**

No unresolved contradiction prevents this document from serving as the stable product baseline. Future product decisions may explicitly supersede it; downstream terminology, domain modeling, architecture and implementation work must derive from it rather than independently reconstructing the historical corpus.
